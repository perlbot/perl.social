{
  "title": "Zero » One Hundred"
}

This is a test post for UTF-8 titles with a JSON front matter.
