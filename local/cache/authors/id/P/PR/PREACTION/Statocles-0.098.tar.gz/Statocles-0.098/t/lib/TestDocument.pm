package TestDocument;

use Statocles::Base 'Class';
extends 'Statocles::Document';


1;
