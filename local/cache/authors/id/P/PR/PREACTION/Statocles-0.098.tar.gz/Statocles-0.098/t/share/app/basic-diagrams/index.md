---
title: this is the index
---

This looks like a sequence diagram.

%= diagram mermaid => begin
sequenceDiagram
loop every day
    Alice->>John: Hello John, how are you?
    John-->>Alice: Great!
end
%= end
