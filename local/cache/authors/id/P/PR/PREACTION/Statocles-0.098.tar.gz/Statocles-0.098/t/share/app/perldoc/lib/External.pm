package
    External;

=head1 NAME

External - A module that is part of our project but not to be included in the POD

=head1 SYNOPSIS

    use External;
    # Does nothing

=head1 DESCRIPTION

This module is to test that this module does not get included with the rest of the
modules, even though it is in the same directory.
