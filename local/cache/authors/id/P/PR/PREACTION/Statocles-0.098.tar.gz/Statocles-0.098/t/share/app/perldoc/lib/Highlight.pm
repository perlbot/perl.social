package Highlight;

1;

=pod

=head1 NAME

Highlight

=head1 DESCRIPTION

Syntax highlight test pod

=head1 SYNOPSIS

This is empty

=cut
