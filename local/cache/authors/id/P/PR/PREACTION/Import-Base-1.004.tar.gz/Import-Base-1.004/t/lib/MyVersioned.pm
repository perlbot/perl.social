package
    MyVersioned;

use vars qw( $VERSION );
$VERSION = 1.5;

1;
