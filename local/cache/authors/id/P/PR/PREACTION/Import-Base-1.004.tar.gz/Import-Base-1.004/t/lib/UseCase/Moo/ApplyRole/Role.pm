package
    UseCase::Moo::ApplyRole::Role;
use UseCase::Moo::ApplyRole 'Role';
around BUILDARGS => sub { };

1;
