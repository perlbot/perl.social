package
    UseCase::Moo::ApplyRole::WithRequires;

use UseCase::Moo::ApplyRole 'Role';
requires 'my_attr';

1;
