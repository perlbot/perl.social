package MyExportInherited;

use base 'MyExport';

1;
