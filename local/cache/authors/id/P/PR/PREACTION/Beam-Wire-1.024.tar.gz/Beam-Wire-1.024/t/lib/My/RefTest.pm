package
    My::RefTest;

use Moo;

has got_ref => ( is => 'ro' );

1;
