package
    My::Emitter;

use Moo;
with 'Beam::Emitter';

1;
