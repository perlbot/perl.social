package
    My::ClassTest;

use Moo;

has foo => ( is => 'ro' );

1;
