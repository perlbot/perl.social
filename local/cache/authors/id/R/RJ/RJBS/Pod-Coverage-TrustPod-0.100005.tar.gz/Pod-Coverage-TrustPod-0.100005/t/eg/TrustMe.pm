
use strict;
use warnings;

package TrustMe;

=head1 NAME

TrustMe - we have an anchor-free trustme and anchored =for

=for Pod::Coverage xyz

=cut

sub foo_zzz_bar { }

sub xyz { }

sub foo_xyz_bar { }

1;
