
use strict;
use warnings;

package NoCoverage;

=head1 NAME

NoCoverage - ain't nothin covered

=cut

sub not_covered { }

1;
