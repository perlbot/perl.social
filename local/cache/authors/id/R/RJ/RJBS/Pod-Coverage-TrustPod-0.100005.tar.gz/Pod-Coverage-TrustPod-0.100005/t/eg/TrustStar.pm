
use strict;
use warnings;

package TrustStar;

=head1 NAME

TrustStar - trust the almight asterisk

=for Pod::Coverage *EVERYTHING*

=cut

sub not_covered { }

sub pants { }

1;
