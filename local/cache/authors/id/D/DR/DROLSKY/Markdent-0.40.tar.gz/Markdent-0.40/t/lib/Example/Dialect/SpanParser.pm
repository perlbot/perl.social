package Example::Dialect::SpanParser;

use strict;
use warnings;
use namespace::autoclean;

use Moose::Role;

with 'Markdent::Role::Dialect::SpanParser';

1;
