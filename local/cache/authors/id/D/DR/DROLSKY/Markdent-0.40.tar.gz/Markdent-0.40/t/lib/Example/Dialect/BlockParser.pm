package Example::Dialect::BlockParser;

use strict;
use warnings;
use namespace::autoclean;

use Moose::Role;

with 'Markdent::Role::Dialect::BlockParser';

1;
